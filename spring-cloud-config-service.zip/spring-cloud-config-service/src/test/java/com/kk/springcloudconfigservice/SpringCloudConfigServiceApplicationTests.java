package com.kk.springcloudconfigservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudConfigServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
